import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-category',
  template: `
  <ul>
  <li  (click)="onSelect(product)" *ngFor="let product of products">
    <span>{{product.id}}</span> {{product.name}}
  </li>
</ul>
  `,
  styles: []
})
export class CategoryComponent implements OnInit {
  public products = [
    {"id": 1, "name": "Tv"},
    {"id": 2, "name": "Mobile"},
    {"id": 3, "name": "FreeZer"},
    
  ]
  constructor(private rounter: Router) { }

  ngOnInit() {
    
  }
  onSelect(products){
    // from neviate from code to rooute we need router service
    this.rounter.navigate(['/product', products.id]);
  }

}
