import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emplist',
  template: `
    <p>
      emplist works!
    </p>
  `,
  styles: []
})
export class EmplistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
